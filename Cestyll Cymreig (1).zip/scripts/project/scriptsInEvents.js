


const scriptsInEvents = {

	async CastlesSheet_Event21_Act1(runtime, localVars)
	{
		alert("Clear")
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

